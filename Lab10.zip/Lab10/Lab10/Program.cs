﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] employeeArray = new Employee[3];
            employeeArray[0] = new Employee { FirstName = "Jesse", LastName = "Liberty" };
            employeeArray[1] = new Employee { FirstName = "Nick", LastName = "Mueller" };
            employeeArray[2] = new Employee { FirstName = "asdf", LastName = "Lisadfberty" };

            for (int i = 0; i < employeeArray.Length; i++)
            {
                Console.WriteLine(employeeArray[i]);
            }

            Console.ReadLine();
        }
    }
}
